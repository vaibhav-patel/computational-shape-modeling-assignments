clear;
close all;
GeodesicCone([-3,-7],[3,7]);
title('P1 = (-3,-7), P2= (3,7)')

figure
GeodesicCone([3,-7],[3,7]);
title('P1 = (-3,-7), P2= (3,7)')
